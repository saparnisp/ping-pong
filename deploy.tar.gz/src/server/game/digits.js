export const DIGITS = [
  {
    shape: [
      [1, 1, 1],
      [1, 0, 1],
      [1, 0, 1],
      [1, 0, 1],
      [1, 1, 1],
    ],
    color: 8,
  },
  {
    shape: [
      [0, 1, 1],
      [0, 0, 1],
      [0, 0, 1],
      [0, 0, 1],
      [0, 0, 1],
    ],
    color: 8,
  },
  {
    shape: [
      [1, 1, 1],
      [0, 0, 1],
      [0, 1, 0],
      [1, 0, 0],
      [1, 1, 1],
    ],
    color: 8,
  },
  {
    shape: [
      [1, 1, 1],
      [0, 0, 1],
      [1, 1, 0],
      [0, 0, 1],
      [1, 1, 1],
    ],
    color: 8,
  },
  {
    shape: [
      [1, 0, 0],
      [1, 0, 1],
      [1, 1, 1],
      [0, 0, 1],
      [0, 0, 1],
    ],
    color: 8,
  },
  {
    shape: [
      [1, 1, 1],
      [1, 0, 0],
      [1, 1, 1],
      [0, 0, 1],
      [1, 1, 1],
    ],
    color: 8,
  },
];

export const createDigit = (value) => {
  const { shape, color } = DIGITS[value];
  const piece = shape.map((row) => row.map((cell) => (cell ? color : 0)));

  return piece;
};
